from django.shortcuts import render
from .forms import UploadPDFForm
from .utils import process_pdf

def upload_pdf(request):
    if request.method == 'POST':
        form = UploadPDFForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded_pdf = form.save()
            summary, keywords = process_pdf(uploaded_pdf.pdf_file.path)  # Access pdf_file correctly
            return render(request, 'result.html', {'summary': summary, 'keywords': keywords})
    else:
        form = UploadPDFForm()
    return render(request, 'upload.html', {'form': form})
