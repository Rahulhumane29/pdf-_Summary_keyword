import PyPDF2
from summa import summarizer, keywords
from langdetect.lang_detect_exception import LangDetectException
import langdetect

def process_pdf(filepath):
    text = ''
    summary = ''
    keywords_list = []

    try:
        with open(filepath, 'rb') as pdf_file:
            reader = PyPDF2.PdfReader(pdf_file)
            num_pages = len(reader.pages)

            for page_num in range(num_pages):
                page = reader.pages[page_num]
                text += page.extract_text()

        # Detect language
        lang = detect_language(text)

        # Summarize the text
        if lang == 'mr':  # If Marathi language detected
            summary = summarizer.summarize(text, ratio=0.2, language='marathi')
        else:  # For other languages (assuming English)
            summary = summarizer.summarize(text, ratio=0.2)

        # Extract keywords
        if lang == 'mr':  # If Marathi language detected
            keywords_list = keywords.keywords(text, ratio=0.2, language='marathi').split('\n')
        else:  # For other languages (assuming English)
            keywords_list = keywords.keywords(text, ratio=0.2).split('\n')

    except LangDetectException as e:
        print(f"Language detection failed: {e}")
        lang = 'en'  # Assuming English as default language
        summary = "Failed to detect language or text is too short for detection."
        keywords_list = []

    return summary, keywords_list

def detect_language(text):
    try:
        lang = langdetect.detect(text)
    except LangDetectException as e:
        print(f"Language detection failed: {e}")
        lang = 'en'  # Assuming English as default language
    return lang
