from django.contrib import admin
from .models import UploadedPDF

class Adminpdf(admin.ModelAdmin):
    list_display = ['pdf_file', 'uploaded_at'] 
admin.site.register(UploadedPDF, Adminpdf)
